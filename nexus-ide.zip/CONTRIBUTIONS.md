# Contributing to Nexus IDE

We love your input! We want to make contributing to Nexus IDE as easy and transparent as possible, whether it's:

- Reporting a bug
- Discussing the current state of the code
- Submitting a fix
- Proposing new features
- Becoming a maintainer

## Development Process

We use GitHub to host code, to track issues and feature requests, as well as accept pull requests.

1. **Fork the repo** and create your branch from `main`.
2. **Install dependencies** using `npm install`.
3. **Run the dev server** using `npm run dev`.
4. **Make your changes**.
5. **Lint and test** your code.
6. **Issue a pull request!**

## Code of Conduct

Please be respectful and professional in all interactions.

## License

By contributing, you agree that your contributions will be licensed under its MIT License.
