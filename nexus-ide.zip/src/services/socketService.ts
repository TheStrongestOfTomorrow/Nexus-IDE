type MessageHandler = (data: any) => void;

class SocketService {
  private socket: WebSocket | null = null;
  private handlers: Set<MessageHandler> = new Set();
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;

  connect() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    this.socket = new WebSocket(`${protocol}//${host}`);

    this.socket.onopen = () => {
      console.log('Connected to Nexus WebSocket');
      this.reconnectAttempts = 0;
    };

    this.socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        this.handlers.forEach(handler => handler(data));
      } catch (err) {
        console.error('Socket message parse error', err);
      }
    };

    this.socket.onclose = () => {
      console.log('Disconnected from Nexus WebSocket');
      if (this.reconnectAttempts < this.maxReconnectAttempts) {
        setTimeout(() => {
          this.reconnectAttempts++;
          this.connect();
        }, 2000);
      }
    };
  }

  send(data: any) {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(data));
    }
  }

  createSession() {
    const sessionId = Math.random().toString(36).substring(2, 10).toUpperCase();
    this.send({ type: 'session:create', sessionId });
    return sessionId;
  }

  joinSession(sessionId: string) {
    this.send({ type: 'session:join', sessionId });
  }

  hostWorkspace(sessionId: string, files: { name: string, content: string }[]) {
    this.send({ type: 'workspace:host', sessionId, files });
  }

  subscribe(handler: MessageHandler) {
    this.handlers.add(handler);
    return () => this.handlers.delete(handler);
  }
}

export const socketService = new SocketService();
