# Contributing to Nexus IDE

We welcome contributions to Nexus IDE! Whether you're fixing bugs, adding features, or improving documentation, your help is appreciated.

## Development Setup

1. Clone the repository.
2. Install dependencies: `npm install`.
3. Start the development server: `npm run dev`.

## Architecture

- **Frontend**: React + Vite + Tailwind CSS.
- **Editor**: Monaco Editor.
- **Backend**: Express + WebSockets.
- **AI**: Integrated with `@google/genai`, `openai`, and `anthropic`.

## Guidelines

- Follow the existing code style.
- Ensure all new features are accessible via the Command Palette.
- Add tests for new functionality (where applicable).
- Update documentation when making significant changes.

## Feature Requests

Have an idea for a "Pro" feature? Open an issue or submit a PR!
